# Liquid Glass TV — 1.5.0

Launcher independente para Android TV, com interface Liquid Glass e wallpaper integrado.

## Recursos desta versão
- Interface 16:9 com painel translúcido e papel de parede espacial.
- Lista de aplicativos instalados, com prioridade para atividades Leanback e deduplicação por pacote.
- Ícones dos aplicativos renderizados a partir dos ícones Android.
- Abertura de aplicativos convencionais e de aplicativos que expõem somente atividade Leanback.
- Navegação por controle remoto com setas, OK/Enter e Voltar, incluindo mapeamento de códigos DPAD comuns.
- Atalho para Configurações do Android.
- Declaração como candidata a HOME; o firmware pode restringir a seleção como launcher padrão.

## Compilação
JDK 17, Android SDK Platform 35, Build Tools 35.0.0 e Gradle 8.7.

```sh
gradle assembleDebug
```

O workflow em `.github/workflows/build-apk.yml` gera o APK debug como artefato do GitHub Actions quando o projeto está no repositório.

## Ainda requer validação física
O projeto não foi compilado nem testado em uma TCL P725 nesta sessão. O firmware, a rolagem/foco em resolução real e o retorno de aplicativos precisam ser verificados antes de definir a launcher padrão. Os cartões de clima e entradas TV/HDMI são visuais, sem integração de dados/controle nesta versão.
