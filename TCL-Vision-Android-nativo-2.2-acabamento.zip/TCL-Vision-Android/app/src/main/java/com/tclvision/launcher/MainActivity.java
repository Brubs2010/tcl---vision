package com.tclvision.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.content.IntentSender;
import android.net.Uri;
import android.util.Log;
import android.util.Base64;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import java.io.ByteArrayOutputStream;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Scope;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(241,244,249);
    private final int INK = Color.rgb(23,31,48);
    private final int MUTED = Color.rgb(111,122,140);
    private final int NAVY = Color.rgb(8,29,58);
    private final int NAVY2 = Color.rgb(12,49,91);
    private final int PURPLE = Color.rgb(100,65,220);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private LinearLayout root, matchList, newsList, appRow;
    private WebView youtubeWebView;
    private static final int REQUEST_YOUTUBE_AUTH = 7412;
    private static final String YOUTUBE_SCOPE = "https://www.googleapis.com/auth/youtube.readonly";
    private String youtubeAccessToken;
    private static final String TAG = "TCLVision";
    private TextView clock, date, weatherTemp, weatherDesc, sportsTitle, sportFootball, sportNba, sportTennis;
    private String currentSport = "football";
    private final List<View> focusables = new ArrayList<>();
    private Runnable clockTick, refreshTick;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        immersive();
        buildHome();
        loadSports();
        loadWeather();
        loadNews();
        loadApps();
        startTimers();
    }

    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private GradientDrawable stroke(int color, int radius, int border) {
        GradientDrawable d = bg(color, radius); d.setStroke(dp(1), border); return d;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL); t.setIncludeFontPadding(false);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        t.setMaxLines(2); return t;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private LinearLayout col() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private void pad(View v, int l, int t, int r, int b) { v.setPadding(dp(l),dp(t),dp(r),dp(b)); }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h)); }
    private void weighted(LinearLayout parent, View child, float weight) {
        parent.addView(child, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight));
    }
    private TextView focusCard(String label, int textSize, int color) {
        TextView v = text(label,textSize,color,true); v.setFocusable(true); v.setClickable(true);
        v.setBackground(stroke(Color.WHITE,16,Color.rgb(222,228,237)));
        v.setOnFocusChangeListener((view, focused) -> {
            view.setScaleX(focused ? 1.045f : 1f); view.setScaleY(focused ? 1.045f : 1f);
            view.setElevation(dp(focused ? 12 : 1));
            view.setBackground(stroke(focused ? Color.WHITE : Color.WHITE,16,focused ? PURPLE : Color.rgb(222,228,237)));
        });
        focusables.add(v); return v;
    }

    private void buildHome() {
        root = col(); root.setBackgroundColor(BG); root.setFocusable(true);
        setContentView(root);

        LinearLayout header = row(); pad(header,34,10,34,8);
        TextView brand = text("TCL VISION",17,INK,true);
        header.addView(brand, lp(150,-1));
        LinearLayout timeCol = col();
        clock = text("--:--",28,INK,true); date = text("",12,MUTED,false);
        timeCol.addView(clock); timeCol.addView(date);
        header.addView(timeCol, new LinearLayout.LayoutParams(0,dp(58),1));
        TextView settings = focusCard("⚙",22,INK); settings.setGravity(Gravity.CENTER);
        settings.setOnClickListener(v -> openAndroidSettings());
        header.addView(settings,lp(54,48));
        TextView classic = focusCard("⋯",22,INK); classic.setGravity(Gravity.CENTER);
        classic.setOnClickListener(v -> startActivity(new Intent(this, WebDashboardActivity.class)));
        LinearLayout.LayoutParams cp=lp(54,48); cp.leftMargin=dp(10); header.addView(classic,cp);
        root.addView(header, new LinearLayout.LayoutParams(-1,dp(78)));

        LinearLayout main = row(); pad(main,26,5,26,5);
        LinearLayout sports = col(); sports.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{NAVY,NAVY2,Color.rgb(15,76,125)})); ((GradientDrawable)sports.getBackground()).setCornerRadius(dp(22));
        pad(sports,20,14,20,14);
        LinearLayout sportHeader = row();
        sportsTitle = text("PLACARES AO VIVO",13,Color.rgb(177,211,255),true);
        sportHeader.addView(sportsTitle,new LinearLayout.LayoutParams(0,dp(26),1));
        TextView live = text("● AO VIVO",11,Color.rgb(120,238,174),true); sportHeader.addView(live);
        sports.addView(sportHeader);
        LinearLayout tabs = row(); tabs.setGravity(Gravity.CENTER_VERTICAL);
        sportFootball = tab("FUTEBOL","football"); sportNba = tab("NBA","nba"); sportTennis = tab("TÊNIS","tennis");
        tabs.addView(sportFootball); tabs.addView(sportNba); tabs.addView(sportTennis);
        LinearLayout.LayoutParams tp=lp(-1,38); tp.topMargin=dp(4); sports.addView(tabs,tp);
        matchList = col(); LinearLayout.LayoutParams mlp=new LinearLayout.LayoutParams(-1,0,1); mlp.topMargin=dp(8); sports.addView(matchList,mlp);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,-1,2.05f); sp.rightMargin=dp(12); main.addView(sports,sp);

        LinearLayout side = col();
        LinearLayout news = col(); news.setBackground(bg(Color.WHITE,18)); pad(news,16,12,16,10);
        LinearLayout nh = row(); nh.addView(text("ÚLTIMAS NOTÍCIAS",14,INK,true),new LinearLayout.LayoutParams(0,dp(24),1));
        nh.addView(text("ESPN",10,MUTED,true)); news.addView(nh);
        newsList=col(); LinearLayout.LayoutParams nlp=new LinearLayout.LayoutParams(-1,0,1); nlp.topMargin=dp(4); news.addView(newsList,nlp);
        side.addView(news,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout weather = col(); weather.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{Color.rgb(34,142,213),Color.rgb(74,181,215),Color.rgb(240,174,151)}));
        ((GradientDrawable)weather.getBackground()).setCornerRadius(dp(18)); pad(weather,16,12,16,10);
        weather.addView(text("ITAPECERICA DA SERRA · SP",12,Color.WHITE,true));
        weatherTemp=text("--°",30,Color.WHITE,true); weatherDesc=text("Consultando previsão…",12,Color.WHITE,false);
        LinearLayout.LayoutParams wtlp=lp(-1,38); wtlp.topMargin=dp(5); weather.addView(weatherTemp,wtlp); weather.addView(weatherDesc);
        LinearLayout.LayoutParams wlp=new LinearLayout.LayoutParams(-1,0,0.82f); wlp.topMargin=dp(10); side.addView(weather,wlp);
        LinearLayout.LayoutParams sidep=new LinearLayout.LayoutParams(0,-1,0.95f); main.addView(side,sidep);
        root.addView(main,new LinearLayout.LayoutParams(-1,0,3.55f));

        LinearLayout youtube = col(); pad(youtube,24,5,24,3);
        LinearLayout yhead=row();
        yhead.addView(text("▶  NOVIDADES DO YOUTUBE",14,INK,true),new LinearLayout.LayoutParams(0,dp(25),1));
        TextView yopen=focusCard("ABRIR YOUTUBE",10,PURPLE); yopen.setGravity(Gravity.CENTER);
        yopen.setOnClickListener(v -> launchFirst(new String[]{"com.google.android.youtube.tv","com.google.android.youtube"}));
        yhead.addView(yopen,lp(132,28)); youtube.addView(yhead);
        youtubeWebView = new WebView(this);
        WebSettings ys=youtubeWebView.getSettings();
        ys.setJavaScriptEnabled(true); ys.setDomStorageEnabled(true); ys.setDatabaseEnabled(true);
        ys.setLoadsImagesAutomatically(true); ys.setMediaPlaybackRequiresUserGesture(false);
        ys.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        youtubeWebView.setBackgroundColor(Color.TRANSPARENT);
        youtubeWebView.setFocusable(true); youtubeWebView.setFocusableInTouchMode(true);
        youtubeWebView.addJavascriptInterface(new YouTubeBridge(), "TCLVisionNative");
        youtubeWebView.setWebChromeClient(new WebChromeClient());
        youtubeWebView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){
                Uri uri=request.getUrl(); String host=uri.getHost()==null?"":uri.getHost();
                if(host.equals("brubs2010.github.io") || host.equals("www.youtube.com") || host.equals("youtube.com")) return false;
                try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception e){Log.w(TAG,"External URL",e);}
                return true;
            }
            @Override public void onPageFinished(WebView view,String url){super.onPageFinished(view,url);styleYoutubeStrip();}
        });
        youtubeWebView.loadUrl("file:///android_asset/index.html");
        youtube.addView(youtubeWebView,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(youtube,new LinearLayout.LayoutParams(-1,0,2.25f));

        LinearLayout apps = col(); pad(apps,28,3,28,10);
        LinearLayout ah=row(); ah.addView(text("SEUS APLICATIVOS",14,INK,true),new LinearLayout.LayoutParams(0,dp(24),1));
        ah.addView(text("Acesso rápido à TV",10,MUTED,false)); apps.addView(ah);
        appRow=row(); appRow.setGravity(Gravity.CENTER_VERTICAL);
        HorizontalScrollView appScroll=new HorizontalScrollView(this);
        appScroll.setHorizontalScrollBarEnabled(false); appScroll.setFillViewport(true);
        appScroll.setClipToPadding(false); appScroll.setPadding(dp(5),0,dp(5),0);
        appRow.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT); appRow.setPadding(dp(5),0,dp(5),0);
        appScroll.addView(appRow);
        appScroll.post(()->appScroll.scrollTo(0,0));
        apps.addView(appScroll,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(apps,new LinearLayout.LayoutParams(-1,0,1.75f));
        updateClock();
    }

    private TextView tab(String label, String sport) {
        TextView t=focusCard(label,11,INK); t.setGravity(Gravity.CENTER); t.setTextColor(sport.equals(currentSport)?INK:Color.WHITE); t.setBackground(bg(sport.equals(currentSport)?Color.WHITE:Color.TRANSPARENT,12));
        t.setOnClickListener(v->{currentSport=sport; updateTabs(); loadSports();});
        LinearLayout.LayoutParams p=lp(sport.equals("football")?100:76,32); p.rightMargin=dp(7);
        t.setLayoutParams(p); return t;
    }
    private void updateTabs() {
        TextView[] tabs={sportFootball,sportNba,sportTennis}; String[] keys={"football","nba","tennis"};
        for(int i=0;i<tabs.length;i++){tabs[i].setBackground(bg(currentSport.equals(keys[i])?Color.WHITE:Color.TRANSPARENT,12));tabs[i].setTextColor(currentSport.equals(keys[i])?INK:Color.WHITE);}
        sportsTitle.setText(currentSport.equals("football")?"FUTEBOL · PLACARES":currentSport.equals("nba")?"NBA · PLACARES":"ATP / WTA · TÊNIS");
    }

    private void addShortcut(LinearLayout parent,String label,String pkg,int color) {
        TextView tile=focusCard(label,11,INK); tile.setGravity(Gravity.CENTER); tile.setCompoundDrawablePadding(dp(5));
        tile.setBackground(stroke(Color.WHITE,12,Color.rgb(225,230,238)));
        tile.setOnClickListener(v->launchPackage(pkg));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(126),dp(43)); p.rightMargin=dp(9); parent.addView(tile,p);
    }

    private void addMatch(String left,String score,String right,String meta) {
        LinearLayout card=row(); card.setBackground(bg(Color.rgb(17,43,77),12)); pad(card,12,5,12,5);
        TextView l=text(left,12,Color.WHITE,true); l.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT); l.setMaxLines(1);
        card.addView(l,new LinearLayout.LayoutParams(0,-1,1));
        TextView s=text(score,15,Color.WHITE,true); s.setGravity(Gravity.CENTER); card.addView(s,lp(74,-1));
        TextView r=text(right,12,Color.WHITE,true); r.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT); r.setMaxLines(1);
        card.addView(r,new LinearLayout.LayoutParams(0,-1,1));
        LinearLayout wrap=col(); wrap.addView(card,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView m=text(meta,9,Color.rgb(183,204,229),false); m.setGravity(Gravity.CENTER); wrap.addView(m,lp(-1,17));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(60)); p.bottomMargin=dp(4); matchList.addView(wrap,p);
    }

    private void loadSports() {
        matchList.removeAllViews(); addMatch("Carregando eventos…","—","Aguarde","Atualizando placares");
        new Thread(()->{
            String url=currentSport.equals("nba")?"https://site.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard":
                currentSport.equals("tennis")?"https://site.api.espn.com/apis/site/v2/sports/tennis/atp/scoreboard":
                "https://site.api.espn.com/apis/site/v2/sports/soccer/bra.1/scoreboard";
            JSONArray events=new JSONArray();
            try {
                JSONObject data=new JSONObject(fetch(url)); events=data.optJSONArray("events"); if(events==null)events=new JSONArray();
                final JSONArray result=events;
                runOnUiThread(()->renderEvents(result));
            } catch(Exception e){runOnUiThread(()->{matchList.removeAllViews();addMatch("Dados indisponíveis","—","ESPN","Tente novamente em alguns minutos");});}
        }).start();
    }

    private void renderEvents(JSONArray events) {
        matchList.removeAllViews();
        int count=Math.min(events.length(),4);
        if(count==0){addMatch("Nenhum evento listado","—","no momento","A programação será atualizada");return;}
        for(int i=0;i<count;i++) {
            JSONObject e=events.optJSONObject(i); if(e==null)continue;
            JSONObject comp=e.optJSONArray("competitions")!=null?e.optJSONArray("competitions").optJSONObject(0):null;
            JSONArray competitors=comp!=null?comp.optJSONArray("competitors"):null;
            String a="Equipe A",b="Equipe B",sa="",sb="",status="";
            if(competitors!=null&&competitors.length()>0){
                JSONObject c=competitors.optJSONObject(0); if(c!=null){a=c.optJSONObject("team")!=null?c.optJSONObject("team").optString("shortDisplayName",c.optJSONObject("team").optString("displayName","Equipe A")):"Equipe A";sa=c.optString("score","");}
                if(competitors.length()>1){JSONObject d=competitors.optJSONObject(1);if(d!=null){b=d.optJSONObject("team")!=null?d.optJSONObject("team").optString("shortDisplayName",d.optJSONObject("team").optString("displayName","Equipe B")):"Equipe B";sb=d.optString("score","");}}
            }
            JSONObject st=e.optJSONObject("status"); if(st!=null){JSONObject type=st.optJSONObject("type");if(type!=null)status=type.optString("shortDetail",type.optString("detail",""));}
            String score=(sa.isEmpty()&&sb.isEmpty())?"VS":sa+" × "+sb;
            addMatch(a,score,b,status.isEmpty()?"ESPN":status);
        }
    }

    private void loadNews() {
        new Thread(()->{
            try {
                JSONObject d=new JSONObject(fetch("https://site.api.espn.com/apis/site/v2/sports/soccer/bra.1/news"));
                JSONArray a=d.optJSONArray("articles");
                List<String> headlines=new ArrayList<>();
                if(a!=null)for(int i=0;i<Math.min(3,a.length());i++){JSONObject o=a.optJSONObject(i);if(o!=null)headlines.add(o.optString("headline",""));}
                runOnUiThread(()->{newsList.removeAllViews();if(headlines.isEmpty())headlines.add("Acompanhe as últimas notícias esportivas");for(String h:headlines){TextView t=text("• "+h,12,INK,true);t.setMaxLines(2);LinearLayout.LayoutParams p=lp(-1,0);p.height=0;p.weight=1;newsList.addView(t,p);}});
            }catch(Exception e){runOnUiThread(()->{newsList.removeAllViews();newsList.addView(text("Notícias esportivas ESPN",12,INK,true));});}
        }).start();
    }

    private void loadWeather() {
        new Thread(()->{
            try {
                JSONObject d=new JSONObject(fetch("https://api.open-meteo.com/v1/forecast?latitude=-23.7167&longitude=-46.85&current=temperature_2m,weather_code&timezone=America%2FSao_Paulo"));
                JSONObject c=d.optJSONObject("current"); final String temp=Math.round(c.optDouble("temperature_2m"))+"°";
                final String desc=weatherLabel(c.optInt("weather_code"));
                runOnUiThread(()->{weatherTemp.setText(temp);weatherDesc.setText(desc+" · Previsão atualizada");});
            }catch(Exception e){runOnUiThread(()->weatherDesc.setText("Previsão indisponível"));}
        }).start();
    }
    private String weatherLabel(int code) {
        if(code==0)return "Céu limpo"; if(code<=3)return "Parcialmente nublado"; if(code<=48)return "Neblina";
        if(code<=67)return "Chuva"; if(code<=77)return "Neve"; if(code<=82)return "Pancadas de chuva"; return "Trovoadas";
    }
    private String fetch(String address)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(7000);c.setRequestProperty("User-Agent","TCLVision/2.0");
        try{BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder b=new StringBuilder();String line;while((line=r.readLine())!=null)b.append(line);r.close();return b.toString();}finally{c.disconnect();}
    }

    private void loadApps() {
        appRow.removeAllViews();
        PackageManager pm=getPackageManager();
        Intent q=new Intent(Intent.ACTION_MAIN,null); q.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> all=pm.queryIntentActivities(q,0);
        final String own=getPackageName();
        final String[] preferred={
            "com.google.android.youtube.tv","com.google.android.youtube",
            "com.netflix.ninja","com.amazon.amazonvideo.livingroom",
            "com.disney.disneyplus","com.espn.score_center"
        };
        List<ResolveInfo> apps=new ArrayList<>();
        for(String wanted:preferred){
            for(ResolveInfo ri:all){
                if(ri.activityInfo.packageName.equals(wanted)){apps.add(ri);break;}
            }
        }
        List<ResolveInfo> remaining=new ArrayList<>();
        for(ResolveInfo ri:all){
            String pkg=ri.activityInfo.packageName;
            if(pkg.equals(own))continue;
            boolean already=false;
            for(ResolveInfo chosen:apps)if(chosen.activityInfo.packageName.equals(pkg)){already=true;break;}
            if(already)continue;
            try{
                int flags=pm.getApplicationInfo(pkg,0).flags;
                if((flags & android.content.pm.ApplicationInfo.FLAG_SYSTEM)!=0)continue;
            }catch(Exception ignored){}
            remaining.add(ri);
        }
        Collections.sort(remaining,(a,b)->String.valueOf(a.loadLabel(pm)).compareToIgnoreCase(String.valueOf(b.loadLabel(pm))));
        apps.addAll(remaining);

        java.util.HashSet<String> seenLabels=new java.util.HashSet<>();
        int added=0;
        for(ResolveInfo info:apps) {
            String pkg=info.activityInfo.packageName;
            if(pkg.equals(own))continue;
            String label=String.valueOf(info.loadLabel(pm)).trim();
            String key=label.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]","");
            if(key.isEmpty() || seenLabels.contains(key))continue;
            seenLabels.add(key);
            if(added>=10)break;

            LinearLayout tile=col(); tile.setGravity(Gravity.CENTER); tile.setFocusable(true); tile.setClickable(true);
            tile.setBackground(stroke(Color.WHITE,13,Color.rgb(225,230,238)));
            ImageView icon=new ImageView(this); icon.setImageDrawable(info.loadIcon(pm));
            icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            tile.addView(icon,lp(30,30));
            TextView name=text(label,9,INK,true); name.setGravity(Gravity.CENTER);
            name.setMaxLines(1); name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams nlp=lp(-1,17); nlp.topMargin=dp(3); tile.addView(name,nlp);
            tile.setContentDescription(label);
            tile.setOnClickListener(v->launchPackage(pkg));
            tile.setOnFocusChangeListener((v,f)->{
                v.setScaleX(f?1.045f:1f); v.setScaleY(f?1.045f:1f);
                v.setElevation(dp(f?9:1));
                v.setBackground(stroke(Color.WHITE,13,f?PURPLE:Color.rgb(225,230,238)));
            });
            LinearLayout.LayoutParams p=lp(102,68); p.rightMargin=dp(9); appRow.addView(tile,p);
            added++;
        }
        if(added==0)appRow.addView(text("Nenhum aplicativo encontrado",12,MUTED,false));
    }

    private void styleYoutubeStrip() {
        if (youtubeWebView == null) return;
        String js = "(function(){"
            + "var old=document.getElementById('tcl-native-youtube-css');if(old)old.remove();"
            + "var css=`html,body{width:100%!important;height:100%!important;overflow:hidden!important;margin:0!important;background:transparent!important}"
            + "body{padding:0!important}header,footer{display:none!important}"
            + "main#inicio{display:block!important;width:100%!important;height:100%!important;max-width:none!important;padding:0!important;margin:0!important;overflow:hidden!important}"
            + "#inicio>.dashboard,#apps{display:none!important}"
            + "#youtube{display:flex!important;flex-direction:column!important;justify-content:flex-start!important;align-items:stretch!important;width:100%!important;height:100%!important;min-height:0!important;margin:0!important;padding:0 5px!important;background:transparent!important;border:0!important;box-shadow:none!important;overflow:hidden!important;gap:5px!important}"
            + "#youtube>.section-title:first-child{display:flex!important;align-items:center!important;justify-content:space-between!important;flex-wrap:nowrap!important;margin:0!important;min-height:30px!important;height:30px!important;gap:8px!important}"
            + "#youtube .youtube-heading{display:none!important}"
            + "#youtube .tabs{display:flex!important;flex-wrap:nowrap!important;gap:7px!important;overflow:hidden!important;align-items:center!important}"
            + "#youtube .tab{font-size:11px!important;padding:6px 13px!important;white-space:nowrap!important;min-height:27px!important;border-radius:16px!important}"
            + "#recentVideos,#popularVideos,#subscriptionsList{display:flex!important;flex:1 1 auto!important;min-height:0!important;height:100%!important;max-height:100%!important;overflow-x:auto!important;overflow-y:hidden!important;align-items:stretch!important;gap:11px!important;padding:3px 3px 5px!important;box-sizing:border-box!important}"
            + "#recentVideos.hidden,#popularVideos.hidden,#subscriptionsList.hidden{display:none!important}"
            + "#youtube .video-card{display:flex!important;flex:0 0 205px!important;width:205px!important;height:100%!important;min-height:0!important;max-height:100%!important;flex-direction:column!important;overflow:hidden!important;border-radius:12px!important;background:#fff!important;box-shadow:0 3px 10px #26375b18!important}"
            + "#youtube .video-card img{display:block!important;flex:0 0 112px!important;width:100%!important;height:112px!important;min-height:112px!important;max-height:112px!important;aspect-ratio:16/9!important;object-fit:cover!important;background:#e8edf5!important}"
            + "#youtube .video-info{display:flex!important;flex:1 1 auto!important;min-height:0!important;flex-direction:column!important;justify-content:center!important;padding:6px 8px!important;overflow:hidden!important}"
            + "#youtube .video-info strong{display:-webkit-box!important;-webkit-line-clamp:2!important;-webkit-box-orient:vertical!important;overflow:hidden!important;font-size:11px!important;line-height:1.2!important}"
            + "#youtube .video-info small{display:block!important;font-size:9px!important;margin-top:3px!important;color:#748096!important}"
            + "#youtube .channel-card{display:flex!important;flex:0 0 112px!important;width:112px!important;height:100%!important;min-height:0!important;max-height:100%!important;padding:8px 5px!important;gap:5px!important;border-radius:12px!important;justify-content:center!important;align-items:center!important;box-sizing:border-box!important}"
            + "#youtube .channel-card img{display:block!important;width:42px!important;height:42px!important;min-width:42px!important;min-height:42px!important;border-radius:50%!important;object-fit:cover!important}"
            + "#youtube .channel-card strong{font-size:10px!important;line-height:1.15!important;max-width:100%!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important}"
            + "#youtube .channel-card small{display:none!important}"
            + "#youtube>.section-title:nth-child(3),#connectionStatus,#subscriptionCount{display:none!important}"
            + "#connectButton,#disconnectButton,#loadMoreButton{font-size:9px!important;padding:5px 9px!important;min-height:24px!important}"
            + "#youtube a:focus,#youtube button:focus{outline:2px solid #7044df!important;outline-offset:1px!important;transform:scale(1.025)!important}"
            + ".empty{font-size:11px!important;padding:8px!important;color:#748096!important}"
            + "`;var st=document.createElement('style');st.id='tcl-native-youtube-css';st.textContent=css;document.head.appendChild(st);"
            + "document.body.classList.add('tv-mode');"
            + "document.querySelectorAll('#youtube .video-card img,#youtube .channel-card img').forEach(function(im){im.loading='eager';im.decoding='async';});"
            + "window.conectarYouTube=function(){var st=document.getElementById('connectionStatus');if(st)st.textContent='Abrindo autorização segura do Google…';if(window.TCLVisionNative)window.TCLVisionNative.requestYouTubeAuthorization();};"
            + "window.addEventListener('tclvision-youtube-token',function(e){try{accessToken=e.detail;nextPageToken=null;totalSubscriptions=0;subscriptionItems=[];var c=document.getElementById('connectButton'),d=document.getElementById('disconnectButton');if(c)c.classList.add('hidden');if(d)d.classList.remove('hidden');if(typeof carregarInscricoes==='function')carregarInscricoes(false);}catch(err){console.error(err);}});"
            + "window.addEventListener('tclvision-youtube-error',function(e){var st=document.getElementById('connectionStatus');if(st)st.textContent=e.detail||'Falha na autorização do YouTube.';});"
            + "var oldDisconnect=window.desconectarYouTube;window.desconectarYouTube=function(){if(window.TCLVisionNative)window.TCLVisionNative.clearYouTubeAuthorization();if(oldDisconnect)oldDisconnect();};"
            + "var connect=document.getElementById('connectButton');if(connect){connect.classList.remove('hidden');connect.textContent='Conectar';var tabs=document.querySelector('#youtube .tabs');if(tabs)tabs.appendChild(connect);}"
            + "})();";
        youtubeWebView.evaluateJavascript(js, null);
    }

    private void authorizeYouTube() {
        AuthorizationRequest request=AuthorizationRequest.builder()
            .setRequestedScopes(Collections.singletonList(new Scope(YOUTUBE_SCOPE))).build();
        Identity.getAuthorizationClient(this).authorize(request)
            .addOnSuccessListener(this,this::handleYouTubeAuthorization)
            .addOnFailureListener(this,e->dispatchYoutubeError("Falha ao iniciar autorização Google."));
    }
    private void handleYouTubeAuthorization(AuthorizationResult result) {
        if(result.hasResolution()){
            try{startIntentSenderForResult(result.getPendingIntent().getIntentSender(),REQUEST_YOUTUBE_AUTH,null,0,0,0);}
            catch(IntentSender.SendIntentException e){dispatchYoutubeError("Não foi possível abrir a autorização.");}
        } else deliverYoutubeToken(result.getAccessToken());
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=REQUEST_YOUTUBE_AUTH)return;
        if(data==null){dispatchYoutubeError("Autorização do Google não retornou dados.");return;}
        try{AuthorizationResult r=Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(data);deliverYoutubeToken(r.getAccessToken());}
        catch(ApiException e){dispatchYoutubeError("O Google não concluiu a autorização.");}
    }
    private void deliverYoutubeToken(String token){
        if(token==null||token.isEmpty()){dispatchYoutubeError("O Google não retornou token.");return;}
        youtubeAccessToken=token;String safe=token.replace("\\\\","\\\\\\\\").replace("'","\\\\'");
        runOnUiThread(()->{if(youtubeWebView!=null)youtubeWebView.evaluateJavascript("window.dispatchEvent(new CustomEvent('tclvision-youtube-token',{detail:'"+safe+"'}));",null);});
    }
    private void dispatchYoutubeError(String message){
        String safe=message.replace("'","").replace("\\n"," ");
        runOnUiThread(()->{if(youtubeWebView!=null)youtubeWebView.evaluateJavascript("window.dispatchEvent(new CustomEvent('tclvision-youtube-error',{detail:'"+safe+"'}));",null);});
    }
    private final class YouTubeBridge {
        @JavascriptInterface public void requestYouTubeAuthorization(){runOnUiThread(MainActivity.this::authorizeYouTube);}
        @JavascriptInterface public void clearYouTubeAuthorization(){youtubeAccessToken=null;}
        @JavascriptInterface public String getInstalledApps(){
            JSONArray result=new JSONArray();
            try{PackageManager pm=getPackageManager();Intent q=new Intent(Intent.ACTION_MAIN,null);q.addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> list=pm.queryIntentActivities(q,0);
                for(ResolveInfo info:list){if(info.activityInfo.packageName.equals(getPackageName()))continue;JSONObject o=new JSONObject();
                    o.put("packageName",info.activityInfo.packageName);o.put("label",String.valueOf(info.loadLabel(pm)));o.put("icon","");
                    try{Drawable d=info.loadIcon(pm);Bitmap b=Bitmap.createBitmap(96,96,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(b);d.setBounds(0,0,96,96);d.draw(c);ByteArrayOutputStream out=new ByteArrayOutputStream();b.compress(Bitmap.CompressFormat.PNG,85,out);o.put("iconData","data:image/png;base64,"+Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP));b.recycle();}catch(Exception ignored){}
                    result.put(o);
                }
            }catch(Exception ignored){} return result.toString();
        }
        @JavascriptInterface public boolean launchApp(String packageName){runOnUiThread(()->launchPackage(packageName));return true;}
    }

    private void launchPackage(String pkg) {
        try{Intent i=getPackageManager().getLaunchIntentForPackage(pkg);if(i!=null)startActivity(i);else Toast.makeText(this,"Aplicativo não disponível",Toast.LENGTH_SHORT).show();}
        catch(Exception e){Toast.makeText(this,"Não foi possível abrir o aplicativo",Toast.LENGTH_SHORT).show();}
    }
    private void launchFirst(String[] packages){for(String p:packages){if(getPackageManager().getLaunchIntentForPackage(p)!=null){launchPackage(p);return;}}startActivity(new Intent(this,WebDashboardActivity.class));}
    private void openAndroidSettings(){try{startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));}catch(Exception e){}}
    private void updateClock(){
        SimpleDateFormat tf=new SimpleDateFormat("HH:mm",new Locale("pt","BR"));
        SimpleDateFormat df=new SimpleDateFormat("EEEE, dd 'de' MMMM",new Locale("pt","BR"));
        clock.setText(tf.format(new Date()));date.setText(df.format(new Date()));
    }
    private void startTimers(){
        clockTick=new Runnable(){public void run(){updateClock();handler.postDelayed(this,30000);}};handler.post(clockTick);
        refreshTick=new Runnable(){public void run(){loadSports();loadNews();loadWeather();handler.postDelayed(this,300000);}};handler.postDelayed(refreshTick,300000);
    }
    @Override public boolean dispatchKeyEvent(KeyEvent event){
        if(event.getKeyCode()==KeyEvent.KEYCODE_BACK&&event.getAction()==KeyEvent.ACTION_UP)return true;
        return super.dispatchKeyEvent(event);
    }
    @Override public void onWindowFocusChanged(boolean f){super.onWindowFocusChanged(f);if(f)immersive();}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);if(youtubeWebView!=null){youtubeWebView.stopLoading();youtubeWebView.destroy();youtubeWebView=null;}super.onDestroy();}
}
