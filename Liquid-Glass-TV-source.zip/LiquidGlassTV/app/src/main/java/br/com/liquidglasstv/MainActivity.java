package br.com.liquidglasstv;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {
    private WebView web;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(8, 12, 30));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new TvBridge(), "TV");
        setContentView(web);
        hideSystemBars();
        web.loadUrl("file:///android_asset/index.html");
    }

    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    @Override public void onBackPressed() {
        if (web != null) web.evaluateJavascript("handleBack()", null);
        else super.onBackPressed();
    }

    private class TvBridge {
        @JavascriptInterface public String getApps() {
            JSONArray out = new JSONArray();
            PackageManager pm = getPackageManager();
            Intent launcher = new Intent(Intent.ACTION_MAIN);
            launcher.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> list = pm.queryIntentActivities(launcher, 0);
            Intent leanback = new Intent(Intent.ACTION_MAIN);
            leanback.addCategory("android.intent.category.LEANBACK_LAUNCHER");
            for (ResolveInfo ri : pm.queryIntentActivities(leanback, 0)) {
                boolean exists = false;
                for (int i=0;i<list.size();i++) if (list.get(i).activityInfo.packageName.equals(ri.activityInfo.packageName)) exists=true;
                if (!exists) list.add(ri);
            }
            Collections.sort(list, Comparator.comparing(a -> a.loadLabel(pm).toString().toLowerCase()));
            for (ResolveInfo ri : list) {
                try {
                    JSONObject item = new JSONObject();
                    item.put("name", ri.loadLabel(pm).toString());
                    item.put("package", ri.activityInfo.packageName);
                    item.put("icon", "");
                    out.put(item);
                } catch (Exception ignored) {}
            }
            return out.toString();
        }

        @JavascriptInterface public boolean launchApp(String packageName) {
            try {
                Intent intent = getPackageManager().getLaunchIntentForPackage(packageName);
                if (intent == null) {
                    intent = new Intent(Intent.ACTION_MAIN);
                    intent.addCategory("android.intent.category.LEANBACK_LAUNCHER");
                    intent.setPackage(packageName);
                }
                if (intent == null) return false;
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                return true;
            } catch (Exception e) { return false; }
        }

        @JavascriptInterface public void openSettings() {
            try { startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); } catch (Exception ignored) {}
        }

        @JavascriptInterface public String deviceName() { return android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL; }
    }
}
