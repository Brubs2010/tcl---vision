package com.tclvision.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(241,244,249);
    private final int INK = Color.rgb(23,31,48);
    private final int MUTED = Color.rgb(111,122,140);
    private final int NAVY = Color.rgb(8,29,58);
    private final int NAVY2 = Color.rgb(12,49,91);
    private final int PURPLE = Color.rgb(100,65,220);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private LinearLayout root, matchList, newsList, appRow;
    private TextView clock, date, weatherTemp, weatherDesc, sportsTitle, sportFootball, sportNba, sportTennis;
    private String currentSport = "football";
    private final List<View> focusables = new ArrayList<>();
    private Runnable clockTick, refreshTick;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        immersive();
        buildHome();
        loadSports();
        loadWeather();
        loadNews();
        loadApps();
        startTimers();
    }

    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private GradientDrawable stroke(int color, int radius, int border) {
        GradientDrawable d = bg(color, radius); d.setStroke(dp(1), border); return d;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL); t.setIncludeFontPadding(false);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        t.setMaxLines(2); return t;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private LinearLayout col() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l;
    }
    private void pad(View v, int l, int t, int r, int b) { v.setPadding(dp(l),dp(t),dp(r),dp(b)); }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h)); }
    private void weighted(LinearLayout parent, View child, float weight) {
        parent.addView(child, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight));
    }
    private TextView focusCard(String label, int textSize, int color) {
        TextView v = text(label,textSize,color,true); v.setFocusable(true); v.setClickable(true);
        v.setBackground(stroke(Color.WHITE,16,Color.rgb(222,228,237)));
        v.setOnFocusChangeListener((view, focused) -> {
            view.setScaleX(focused ? 1.045f : 1f); view.setScaleY(focused ? 1.045f : 1f);
            view.setElevation(dp(focused ? 12 : 1));
            view.setBackground(stroke(focused ? Color.WHITE : Color.WHITE,16,focused ? PURPLE : Color.rgb(222,228,237)));
        });
        focusables.add(v); return v;
    }

    private void buildHome() {
        root = col(); root.setBackgroundColor(BG); root.setFocusable(true);
        setContentView(root);

        LinearLayout header = row(); pad(header,34,10,34,8);
        TextView brand = text("TCL VISION",17,INK,true);
        header.addView(brand, lp(150,-1));
        LinearLayout timeCol = col();
        clock = text("--:--",28,INK,true); date = text("",12,MUTED,false);
        timeCol.addView(clock); timeCol.addView(date);
        header.addView(timeCol, new LinearLayout.LayoutParams(0,dp(58),1));
        TextView settings = focusCard("⚙",22,INK); settings.setGravity(Gravity.CENTER);
        settings.setOnClickListener(v -> openAndroidSettings());
        header.addView(settings,lp(54,48));
        TextView classic = focusCard("⋯",22,INK); classic.setGravity(Gravity.CENTER);
        classic.setOnClickListener(v -> startActivity(new Intent(this, WebDashboardActivity.class)));
        LinearLayout.LayoutParams cp=lp(54,48); cp.leftMargin=dp(10); header.addView(classic,cp);
        root.addView(header, new LinearLayout.LayoutParams(-1,dp(78)));

        LinearLayout main = row(); pad(main,26,5,26,5);
        LinearLayout sports = col(); sports.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{NAVY,NAVY2,Color.rgb(15,76,125)})); ((GradientDrawable)sports.getBackground()).setCornerRadius(dp(22));
        pad(sports,20,14,20,14);
        LinearLayout sportHeader = row();
        sportsTitle = text("PLACARES AO VIVO",13,Color.rgb(177,211,255),true);
        sportHeader.addView(sportsTitle,new LinearLayout.LayoutParams(0,dp(26),1));
        TextView live = text("● AO VIVO",11,Color.rgb(120,238,174),true); sportHeader.addView(live);
        sports.addView(sportHeader);
        LinearLayout tabs = row(); tabs.setGravity(Gravity.CENTER_VERTICAL);
        sportFootball = tab("FUTEBOL","football"); sportNba = tab("NBA","nba"); sportTennis = tab("TÊNIS","tennis");
        tabs.addView(sportFootball); tabs.addView(sportNba); tabs.addView(sportTennis);
        LinearLayout.LayoutParams tp=lp(-1,38); tp.topMargin=dp(4); sports.addView(tabs,tp);
        matchList = col(); LinearLayout.LayoutParams mlp=new LinearLayout.LayoutParams(-1,0,1); mlp.topMargin=dp(8); sports.addView(matchList,mlp);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,-1,2.05f); sp.rightMargin=dp(12); main.addView(sports,sp);

        LinearLayout side = col();
        LinearLayout news = col(); news.setBackground(bg(Color.WHITE,18)); pad(news,16,12,16,10);
        LinearLayout nh = row(); nh.addView(text("ÚLTIMAS NOTÍCIAS",14,INK,true),new LinearLayout.LayoutParams(0,dp(24),1));
        nh.addView(text("ESPN",10,MUTED,true)); news.addView(nh);
        newsList=col(); LinearLayout.LayoutParams nlp=new LinearLayout.LayoutParams(-1,0,1); nlp.topMargin=dp(4); news.addView(newsList,nlp);
        side.addView(news,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout weather = col(); weather.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{Color.rgb(34,142,213),Color.rgb(74,181,215),Color.rgb(240,174,151)}));
        ((GradientDrawable)weather.getBackground()).setCornerRadius(dp(18)); pad(weather,16,12,16,10);
        weather.addView(text("ITAPECERICA DA SERRA · SP",12,Color.WHITE,true));
        weatherTemp=text("--°",30,Color.WHITE,true); weatherDesc=text("Consultando previsão…",12,Color.WHITE,false);
        LinearLayout.LayoutParams wtlp=lp(-1,38); wtlp.topMargin=dp(5); weather.addView(weatherTemp,wtlp); weather.addView(weatherDesc);
        LinearLayout.LayoutParams wlp=new LinearLayout.LayoutParams(-1,0,0.82f); wlp.topMargin=dp(10); side.addView(weather,wlp);
        LinearLayout.LayoutParams sidep=new LinearLayout.LayoutParams(0,-1,0.95f); main.addView(side,sidep);
        root.addView(main,new LinearLayout.LayoutParams(-1,0,4.4f));

        LinearLayout youtube = col(); pad(youtube,28,8,28,4);
        LinearLayout yhead=row(); yhead.addView(text("▶  YOUTUBE",16,INK,true),new LinearLayout.LayoutParams(0,dp(28),1));
        TextView ymore=focusCard("ABRIR YOUTUBE",10,PURPLE); ymore.setGravity(Gravity.CENTER); ymore.setOnClickListener(v -> launchFirst(new String[]{"com.google.android.youtube.tv","com.google.android.youtube"}));
        yhead.addView(ymore,lp(142,30)); youtube.addView(yhead);
        LinearLayout ytrow=row(); ytrow.setGravity(Gravity.CENTER_VERTICAL);
        addShortcut(ytrow,"YouTube","com.google.android.youtube.tv",Color.rgb(230,35,35));
        addShortcut(ytrow,"YouTube","com.google.android.youtube",Color.rgb(230,35,35));
        addShortcut(ytrow,"ESPN","com.espn.score_center",Color.rgb(20,80,160));
        addShortcut(ytrow,"Netflix","com.netflix.ninja",Color.rgb(180,20,35));
        addShortcut(ytrow,"Prime Video","com.amazon.amazonvideo.livingroom",Color.rgb(25,105,170));
        HorizontalScrollView yscroll=new HorizontalScrollView(this); yscroll.setHorizontalScrollBarEnabled(false); yscroll.addView(ytrow);
        youtube.addView(yscroll,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(youtube,new LinearLayout.LayoutParams(-1,0,1.75f));

        LinearLayout apps = col(); pad(apps,28,4,28,12);
        LinearLayout ah=row(); ah.addView(text("SEUS APLICATIVOS",14,INK,true),new LinearLayout.LayoutParams(0,dp(24),1));
        ah.addView(text("Acesso rápido à TV",10,MUTED,false)); apps.addView(ah);
        appRow=row(); appRow.setGravity(Gravity.CENTER_VERTICAL);
        HorizontalScrollView appScroll=new HorizontalScrollView(this); appScroll.setHorizontalScrollBarEnabled(false); appScroll.addView(appRow);
        apps.addView(appScroll,new LinearLayout.LayoutParams(-1,0,1));
        root.addView(apps,new LinearLayout.LayoutParams(-1,0,1.45f));
        updateClock();
    }

    private TextView tab(String label, String sport) {
        TextView t=focusCard(label,11,INK); t.setGravity(Gravity.CENTER); t.setBackground(bg(sport.equals(currentSport)?Color.WHITE:Color.TRANSPARENT,12));
        t.setOnClickListener(v->{currentSport=sport; updateTabs(); loadSports();});
        LinearLayout.LayoutParams p=lp(sport.equals("football")?100:76,32); p.rightMargin=dp(7);
        t.setLayoutParams(p); return t;
    }
    private void updateTabs() {
        TextView[] tabs={sportFootball,sportNba,sportTennis}; String[] keys={"football","nba","tennis"};
        for(int i=0;i<tabs.length;i++){tabs[i].setBackground(bg(currentSport.equals(keys[i])?Color.WHITE:Color.TRANSPARENT,12));tabs[i].setTextColor(currentSport.equals(keys[i])?INK:Color.WHITE);}
        sportsTitle.setText(currentSport.equals("football")?"FUTEBOL · PLACARES":currentSport.equals("nba")?"NBA · PLACARES":"ATP / WTA · TÊNIS");
    }

    private void addShortcut(LinearLayout parent,String label,String pkg,int color) {
        TextView tile=focusCard(label,11,INK); tile.setGravity(Gravity.CENTER); tile.setCompoundDrawablePadding(dp(5));
        tile.setBackground(stroke(Color.WHITE,12,Color.rgb(225,230,238)));
        tile.setOnClickListener(v->launchPackage(pkg));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(126),dp(43)); p.rightMargin=dp(9); parent.addView(tile,p);
    }

    private void addMatch(String left,String score,String right,String meta) {
        LinearLayout card=row(); card.setBackground(bg(Color.rgb(17,43,77),12)); pad(card,12,5,12,5);
        TextView l=text(left,12,Color.WHITE,true); l.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT); l.setMaxLines(1);
        card.addView(l,new LinearLayout.LayoutParams(0,-1,1));
        TextView s=text(score,15,Color.WHITE,true); s.setGravity(Gravity.CENTER); card.addView(s,lp(74,-1));
        TextView r=text(right,12,Color.WHITE,true); r.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT); r.setMaxLines(1);
        card.addView(r,new LinearLayout.LayoutParams(0,-1,1));
        LinearLayout wrap=col(); wrap.addView(card,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView m=text(meta,9,Color.rgb(183,204,229),false); m.setGravity(Gravity.CENTER); wrap.addView(m,lp(-1,17));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(60)); p.bottomMargin=dp(4); matchList.addView(wrap,p);
    }

    private void loadSports() {
        matchList.removeAllViews(); addMatch("Carregando eventos…","—","Aguarde","Atualizando placares");
        new Thread(()->{
            String url=currentSport.equals("nba")?"https://site.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard":
                currentSport.equals("tennis")?"https://site.api.espn.com/apis/site/v2/sports/tennis/atp/scoreboard":
                "https://site.api.espn.com/apis/site/v2/sports/soccer/bra.1/scoreboard";
            JSONArray events=new JSONArray();
            try {
                JSONObject data=new JSONObject(fetch(url)); events=data.optJSONArray("events"); if(events==null)events=new JSONArray();
                final JSONArray result=events;
                runOnUiThread(()->renderEvents(result));
            } catch(Exception e){runOnUiThread(()->{matchList.removeAllViews();addMatch("Dados indisponíveis","—","ESPN","Tente novamente em alguns minutos");});}
        }).start();
    }

    private void renderEvents(JSONArray events) {
        matchList.removeAllViews();
        int count=Math.min(events.length(),4);
        if(count==0){addMatch("Nenhum evento listado","—","no momento","A programação será atualizada");return;}
        for(int i=0;i<count;i++) {
            JSONObject e=events.optJSONObject(i); if(e==null)continue;
            JSONObject comp=e.optJSONArray("competitions")!=null?e.optJSONArray("competitions").optJSONObject(0):null;
            JSONArray competitors=comp!=null?comp.optJSONArray("competitors"):null;
            String a="Equipe A",b="Equipe B",sa="",sb="",status="";
            if(competitors!=null&&competitors.length()>0){
                JSONObject c=competitors.optJSONObject(0); if(c!=null){a=c.optJSONObject("team")!=null?c.optJSONObject("team").optString("shortDisplayName",c.optJSONObject("team").optString("displayName","Equipe A")):"Equipe A";sa=c.optString("score","");}
                if(competitors.length()>1){JSONObject d=competitors.optJSONObject(1);if(d!=null){b=d.optJSONObject("team")!=null?d.optJSONObject("team").optString("shortDisplayName",d.optJSONObject("team").optString("displayName","Equipe B")):"Equipe B";sb=d.optString("score","");}}
            }
            JSONObject st=e.optJSONObject("status"); if(st!=null){JSONObject type=st.optJSONObject("type");if(type!=null)status=type.optString("shortDetail",type.optString("detail",""));}
            String score=(sa.isEmpty()&&sb.isEmpty())?"VS":sa+" × "+sb;
            addMatch(a,score,b,status.isEmpty()?"ESPN":status);
        }
    }

    private void loadNews() {
        new Thread(()->{
            try {
                JSONObject d=new JSONObject(fetch("https://site.api.espn.com/apis/site/v2/sports/soccer/bra.1/news"));
                JSONArray a=d.optJSONArray("articles");
                List<String> headlines=new ArrayList<>();
                if(a!=null)for(int i=0;i<Math.min(3,a.length());i++){JSONObject o=a.optJSONObject(i);if(o!=null)headlines.add(o.optString("headline",""));}
                runOnUiThread(()->{newsList.removeAllViews();if(headlines.isEmpty())headlines.add("Acompanhe as últimas notícias esportivas");for(String h:headlines){TextView t=text("• "+h,12,INK,true);t.setMaxLines(2);LinearLayout.LayoutParams p=lp(-1,0);p.height=0;p.weight=1;newsList.addView(t,p);}});
            }catch(Exception e){runOnUiThread(()->{newsList.removeAllViews();newsList.addView(text("Notícias esportivas ESPN",12,INK,true));});}
        }).start();
    }

    private void loadWeather() {
        new Thread(()->{
            try {
                JSONObject d=new JSONObject(fetch("https://api.open-meteo.com/v1/forecast?latitude=-23.7167&longitude=-46.85&current=temperature_2m,weather_code&timezone=America%2FSao_Paulo"));
                JSONObject c=d.optJSONObject("current"); final String temp=Math.round(c.optDouble("temperature_2m"))+"°";
                final String desc=weatherLabel(c.optInt("weather_code"));
                runOnUiThread(()->{weatherTemp.setText(temp);weatherDesc.setText(desc+" · Previsão atualizada");});
            }catch(Exception e){runOnUiThread(()->weatherDesc.setText("Previsão indisponível"));}
        }).start();
    }
    private String weatherLabel(int code) {
        if(code==0)return "Céu limpo"; if(code<=3)return "Parcialmente nublado"; if(code<=48)return "Neblina";
        if(code<=67)return "Chuva"; if(code<=77)return "Neve"; if(code<=82)return "Pancadas de chuva"; return "Trovoadas";
    }
    private String fetch(String address)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(address).openConnection();c.setConnectTimeout(7000);c.setReadTimeout(7000);c.setRequestProperty("User-Agent","TCLVision/2.0");
        try{BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder b=new StringBuilder();String line;while((line=r.readLine())!=null)b.append(line);r.close();return b.toString();}finally{c.disconnect();}
    }

    private void loadApps() {
        appRow.removeAllViews();
        PackageManager pm=getPackageManager(); Intent q=new Intent(Intent.ACTION_MAIN,null);q.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps=pm.queryIntentActivities(q,0); Collections.sort(apps,(a,b)->String.valueOf(a.loadLabel(pm)).compareToIgnoreCase(String.valueOf(b.loadLabel(pm))));
        int added=0;
        for(ResolveInfo info:apps) {
            if(info.activityInfo.packageName.equals(getPackageName()))continue;
            if(added>=12)break;
            LinearLayout tile=col();tile.setGravity(Gravity.CENTER);tile.setFocusable(true);tile.setClickable(true);tile.setBackground(stroke(Color.WHITE,13,Color.rgb(225,230,238)));
            ImageView icon=new ImageView(this);icon.setImageDrawable(info.loadIcon(pm));icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
            tile.addView(icon,lp(34,34));
            TextView label=text(String.valueOf(info.loadLabel(pm)),10,INK,true);label.setGravity(Gravity.CENTER);label.setMaxLines(1);
            LinearLayout.LayoutParams tlp=lp(-1,18);tlp.topMargin=dp(3);tile.addView(label,tlp);
            String pkg=info.activityInfo.packageName;tile.setOnClickListener(v->launchPackage(pkg));
            tile.setOnFocusChangeListener((v,f)->{v.setScaleX(f?1.06f:1f);v.setScaleY(f?1.06f:1f);v.setElevation(dp(f?10:1));v.setBackground(stroke(Color.WHITE,13,f?PURPLE:Color.rgb(225,230,238)));});
            LinearLayout.LayoutParams p=lp(112,62);p.rightMargin=dp(8);appRow.addView(tile,p);added++;
        }
        if(added==0)appRow.addView(text("Nenhum aplicativo encontrado",12,MUTED,false));
    }

    private void launchPackage(String pkg) {
        try{Intent i=getPackageManager().getLaunchIntentForPackage(pkg);if(i!=null)startActivity(i);else Toast.makeText(this,"Aplicativo não disponível",Toast.LENGTH_SHORT).show();}
        catch(Exception e){Toast.makeText(this,"Não foi possível abrir o aplicativo",Toast.LENGTH_SHORT).show();}
    }
    private void launchFirst(String[] packages){for(String p:packages){if(getPackageManager().getLaunchIntentForPackage(p)!=null){launchPackage(p);return;}}startActivity(new Intent(this,WebDashboardActivity.class));}
    private void openAndroidSettings(){try{startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));}catch(Exception e){}}
    private void updateClock(){
        SimpleDateFormat tf=new SimpleDateFormat("HH:mm",new Locale("pt","BR"));
        SimpleDateFormat df=new SimpleDateFormat("EEEE, dd 'de' MMMM",new Locale("pt","BR"));
        clock.setText(tf.format(new Date()));date.setText(df.format(new Date()));
    }
    private void startTimers(){
        clockTick=new Runnable(){public void run(){updateClock();handler.postDelayed(this,30000);}};handler.post(clockTick);
        refreshTick=new Runnable(){public void run(){loadSports();loadNews();loadWeather();handler.postDelayed(this,300000);}};handler.postDelayed(refreshTick,300000);
    }
    @Override public boolean dispatchKeyEvent(KeyEvent event){
        if(event.getKeyCode()==KeyEvent.KEYCODE_BACK&&event.getAction()==KeyEvent.ACTION_UP)return true;
        return super.dispatchKeyEvent(event);
    }
    @Override public void onWindowFocusChanged(boolean f){super.onWindowFocusChanged(f);if(f)immersive();}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);super.onDestroy();}
}
