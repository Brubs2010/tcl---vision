package br.com.liquidglasstv;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private WebView web;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(8, 12, 30));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setMediaPlaybackRequiresUserGesture(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new TvBridge(), "TV");
        setContentView(web);
        hideSystemBars();
        web.loadUrl("file:///android_asset/index.html");
    }

    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    @Override public void onBackPressed() {
        if (web != null) {
            web.evaluateJavascript("if (typeof handleBack === 'function') handleBack();", null);
        } else {
            super.onBackPressed();
        }
    }

    private class TvBridge {
        @JavascriptInterface public String getApps() {
            JSONArray out = new JSONArray();
            PackageManager pm = getPackageManager();
            // Deduplicate by package. Prefer the Android TV (Leanback) activity when present.
            Map<String, ResolveInfo> unique = new LinkedHashMap<>();
            Intent leanback = new Intent(Intent.ACTION_MAIN);
            leanback.addCategory("android.intent.category.LEANBACK_LAUNCHER");
            for (ResolveInfo ri : pm.queryIntentActivities(leanback, 0)) {
                unique.put(ri.activityInfo.packageName, ri);
            }
            Intent launcher = new Intent(Intent.ACTION_MAIN);
            launcher.addCategory(Intent.CATEGORY_LAUNCHER);
            for (ResolveInfo ri : pm.queryIntentActivities(launcher, 0)) {
                if (!unique.containsKey(ri.activityInfo.packageName)) {
                    unique.put(ri.activityInfo.packageName, ri);
                }
            }
            List<ResolveInfo> list = new java.util.ArrayList<>(unique.values());
            Collections.sort(list, Comparator.comparing(a -> a.loadLabel(pm).toString().toLowerCase()));
            for (ResolveInfo ri : list) {
                try {
                    JSONObject item = new JSONObject();
                    item.put("name", ri.loadLabel(pm).toString());
                    item.put("package", ri.activityInfo.packageName);
                    Drawable drawable = ri.loadIcon(pm);
                    Bitmap bitmap = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888);
                    Canvas canvas = new Canvas(bitmap);
                    drawable.setBounds(0, 0, 128, 128);
                    drawable.draw(canvas);
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                    item.put("icon", "data:image/png;base64," + Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP));
                    bitmap.recycle();
                    out.put(item);
                } catch (Exception ignored) {}
            }
            return out.toString();
        }

        @JavascriptInterface public boolean launchApp(String packageName) {
            if (packageName == null || packageName.trim().isEmpty()) return false;
            try {
                PackageManager pm = getPackageManager();
                Intent intent = pm.getLaunchIntentForPackage(packageName);

                // Algumas apps de TV expõem apenas a atividade LEANBACK_LAUNCHER.
                if (intent == null) {
                    Intent leanback = new Intent(Intent.ACTION_MAIN);
                    leanback.addCategory("android.intent.category.LEANBACK_LAUNCHER");
                    leanback.setPackage(packageName);
                    List<ResolveInfo> matches = pm.queryIntentActivities(leanback, 0);
                    if (matches == null || matches.isEmpty()) return false;
                    ResolveInfo match = matches.get(0);
                    intent = new Intent(Intent.ACTION_MAIN);
                    intent.addCategory("android.intent.category.LEANBACK_LAUNCHER");
                    intent.setClassName(match.activityInfo.packageName, match.activityInfo.name);
                }

                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface public void openSettings() {
            try { startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS)); } catch (Exception ignored) {}
        }

        @JavascriptInterface public String deviceName() { return android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL; }
    }
}
