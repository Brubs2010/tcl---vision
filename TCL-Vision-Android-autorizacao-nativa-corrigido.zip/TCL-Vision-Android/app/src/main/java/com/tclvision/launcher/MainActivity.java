package com.tclvision.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.IntentSender;
import android.net.Uri;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.ClearTokenRequest;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Scope;

import java.util.Collections;

public class MainActivity extends Activity {
    private static final String TAG = "TCLVision";
    private static final int REQUEST_YOUTUBE_AUTH = 7412;
    private static final String SITE_URL = "https://brubs2010.github.io/tcl---vision/";
    private static final String YOUTUBE_SCOPE = "https://www.googleapis.com/auth/youtube.readonly";
    private WebView webView;
    private String accessToken;

    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        immersive();
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        webView.requestFocus(View.FOCUS_DOWN);
        webView.addJavascriptInterface(new NativeBridge(), "TCLVisionNative");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String host = uri.getHost() == null ? "" : uri.getHost();
                if (host.equals("brubs2010.github.io")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                catch (Exception e) { Log.w(TAG, "No external handler for " + uri, e); }
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                installYouTubeBridge();
            }
        });
        webView.loadUrl(SITE_URL);
    }

    private void installYouTubeBridge() {
        String js =
            "(function(){" +
            "if(window.__tclNativeBridgeReady)return;window.__tclNativeBridgeReady=true;" +
            "window.conectarYouTube=function(){" +
            "var s=document.getElementById('connectionStatus');if(s)s.textContent='Abrindo autorização segura do Google…';" +
            "if(window.TCLVisionNative)window.TCLVisionNative.requestYouTubeAuthorization();" +
            "};" +
            "window.addEventListener('tclvision-youtube-token',function(e){" +
            "try{accessToken=e.detail;nextPageToken=null;totalSubscriptions=0;subscriptionItems=[];" +
            "var c=document.getElementById('connectButton'),d=document.getElementById('disconnectButton');" +
            "if(c)c.classList.add('hidden');if(d)d.classList.remove('hidden');" +
            "if(typeof carregarInscricoes==='function')carregarInscricoes(false);" +
            "}catch(err){console.error(err);}" +
            "});" +
            "window.addEventListener('tclvision-youtube-error',function(e){" +
            "var s=document.getElementById('connectionStatus');if(s)s.textContent=e.detail||'Falha na autorização do YouTube.';" +
            "});" +
            "var oldDisconnect=window.desconectarYouTube;" +
            "window.desconectarYouTube=function(){if(window.TCLVisionNative)window.TCLVisionNative.clearYouTubeAuthorization();if(oldDisconnect)oldDisconnect();};" +
            "})();";
        webView.evaluateJavascript(js, null);
    }

    private void authorizeYouTube() {
        AuthorizationRequest request = AuthorizationRequest.builder()
            .setRequestedScopes(Collections.singletonList(new Scope(YOUTUBE_SCOPE)))
            .build();
        Identity.getAuthorizationClient(this).authorize(request)
            .addOnSuccessListener(this, this::handleAuthorization)
            .addOnFailureListener(this, e -> {
                Log.e(TAG, "YouTube authorization failed", e);
                dispatchError("Falha ao iniciar autorização Google: " + safe(e));
            });
    }

    private void handleAuthorization(AuthorizationResult result) {
        if (result.hasResolution()) {
            try {
                startIntentSenderForResult(result.getPendingIntent().getIntentSender(),
                    REQUEST_YOUTUBE_AUTH, null, 0, 0, 0);
            } catch (IntentSender.SendIntentException e) {
                Log.e(TAG, "Authorization resolution failed", e);
                dispatchError("Não foi possível abrir a autorização do Google.");
            }
        } else {
            deliverToken(result.getAccessToken());
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_YOUTUBE_AUTH) return;
        Log.d(TAG, "YouTube authorization returned. resultCode=" + resultCode
            + ", dataPresent=" + (data != null));
        if (data == null) {
            dispatchError("O Google fechou a autorização sem retornar os dados. Tente novamente.");
            return;
        }
        try {
            // O fluxo do Google pode devolver o resultado no Intent mesmo quando
            // o código de retorno do Android não é RESULT_OK. Sempre tentamos
            // extrair o AuthorizationResult antes de tratar como cancelamento.
            AuthorizationResult result = Identity.getAuthorizationClient(this)
                .getAuthorizationResultFromIntent(data);
            deliverToken(result.getAccessToken());
        } catch (ApiException e) {
            Log.e(TAG, "Authorization result failed. resultCode=" + resultCode, e);
            dispatchError("O Google não concluiu a autorização: " + safe(e));
        }
    }

    private void deliverToken(String token) {
        if (token == null || token.isEmpty()) {
            dispatchError("O Google não retornou um token de acesso.");
            return;
        }
        accessToken = token;
        String value = token.replace("\\", "\\\\").replace("'", "\\'");
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(
                "window.dispatchEvent(new CustomEvent('tclvision-youtube-token',{detail:'" + value + "'}));", null);
        });
    }

    private void dispatchError(String message) {
        String value = message == null ? "" : message.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(
                "window.dispatchEvent(new CustomEvent('tclvision-youtube-error',{detail:'" + value + "'}));", null);
        });
    }

    private String safe(Exception e) {
        String m = e.getMessage();
        return m == null ? e.getClass().getSimpleName() : m.replace("'", "").replace("\n", " ");
    }

    private final class NativeBridge {
        @JavascriptInterface public void requestYouTubeAuthorization() {
            runOnUiThread(MainActivity.this::authorizeYouTube);
        }
        @JavascriptInterface public void clearYouTubeAuthorization() {
            String token = accessToken;
            accessToken = null;
            if (token != null) {
                Identity.getAuthorizationClient(MainActivity.this)
                    .clearToken(ClearTokenRequest.builder().setToken(token).build())
                    .addOnFailureListener(e -> Log.w(TAG, "Token clear failed", e));
            }
        }
    }

    @Override public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);
        if (focused) immersive();
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
            if (webView != null && webView.canGoBack()) webView.goBack();
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    @Override protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.removeJavascriptInterface("TCLVisionNative");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
