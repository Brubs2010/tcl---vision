# Liquid Glass TV

Projeto Android TV independente para TCL P725 (Android TV 11), inspirado na referência Liquid Glass enviada pelo usuário.

## Build
Requer JDK 17, Android SDK Platform 35 e Gradle 8.7.
`gradle assembleDebug`

O workflow `.github/workflows/build-apk.yml` compila o APK por GitHub Actions.

## Observações
- O aplicativo consulta os apps com intents LAUNCHER/LEANBACK_LAUNCHER e tenta abri-los pelo PackageManager.
- A categoria HOME permite que o Android ofereça a escolha de launcher padrão. Não altera nem remove a launcher original.
- O cartão de clima é demonstrativo nesta primeira base; integração de clima exige fonte de dados e localização configurada.
- O visual usa fundo vetorial/CSS nesta base inicial; a arte cinematográfica final será adicionada após validação do layout.
- Os ícones nesta primeira compilação são glifos provisórios; a próxima etapa usa os ícones reais retornados pelo Android PackageManager.
